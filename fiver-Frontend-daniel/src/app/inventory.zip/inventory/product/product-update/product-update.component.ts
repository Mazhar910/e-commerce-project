import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {NgxSpinnerService} from 'ngx-spinner';
import {InventoryApiService} from '../../InventoryApi.service';
import {Router} from '@angular/router';
import {InventoryDialogService} from '../../_modal/InventoryDialog.service';
import {InventoryEndPoints} from '../../InventoryEndPoints';
import {environment} from '../../../../environments/environment';

@Component({
    selector: 'app-product-update',
    templateUrl: './product-update.component.html',
    styleUrls: ['./product-update.component.css']
})
export class ProductUpdateComponent implements OnInit {

    submitted = false;
    updateData: FormGroup;
    fileName: any;
    base64textString: any;
    oldImage: any;
    product: any;

    constructor(private modalService: NgbModal,
                private formBuilder: FormBuilder,
                private spinner: NgxSpinnerService,
                private apiService: InventoryApiService,
                private router: Router,
                private dialogService: InventoryDialogService,
                private endpoints: InventoryEndPoints) {
    }

    ngOnInit(): void {
        console.log(localStorage.getItem('product_id'));
        this.getProduct();
        this.formInitialization();
    }

    formInitialization() {
        this.updateData = new FormGroup({
            name: new FormControl('', [
                Validators.required,
            ]),

            purchasedPrice: new FormControl('', [
                Validators.required,
            ]),

            details: new FormControl('', [
                Validators.required,
            ]),

            outletStockQty: new FormControl('', [
                Validators.required,
            ]),

            stockType: new FormControl('In house', [
                Validators.required,
            ]),

            brandName: new FormControl('', [
                Validators.required,
            ]),

            sellingPrice: new FormControl('', [
                Validators.required,
            ]),

            vendorDetails: new FormControl('', [
                Validators.required,
            ]),


            alertQty: new FormControl('', [
                Validators.required,
            ]),

            numOfService: new FormControl('', [
                Validators.required,
            ]),

            isActive: new FormControl(true),
            isDeleted: new FormControl(false),
            createdDate: new FormControl((new Date).getTime())
        });
    }

    update(product_image) {
        this.spinner.show();
        this.onUploadChange(product_image.files[0]);

        setTimeout(() => {
            if (product_image.files[0] === undefined || product_image.files[0] === null) {
                this.updateData.addControl('image', new FormControl(this.oldImage));
                console.log(product_image.files[0]);
                console.log(this.oldImage);
            } else {
                this.updateData.addControl('image', new FormControl(this.base64textString));
                console.log(this.base64textString);
            }
            this.updateData.addControl('createdBy', new FormControl(1));

            console.log(this.updateData.value);

            this.apiService.put(this.updateData.value, this.endpoints.updateProduct, localStorage.getItem('product_id')).subscribe((response: any) => {
                    console.log(response);
                    this.spinner.hide();
                    if (response.status) {
                        this.dialogService.open(response.data.message, response.message, 'success', environment.info);
                    } else {
                        this.dialogService.open(response.data.message, response.message, 'danger', environment.error);
                    }
                    this.updateData.reset();
                    this.formInitialization();
                },
                error => {
                    this.spinner.hide();
                    this.dialogService.open('Something went wrong!', environment.error_message, 'danger', environment.error);
                }
            );
        }, 1000);

    }

    onUploadChange(file: any): any {
        if (file) {
            const reader = new FileReader();
            this.fileName = file.name;
            reader.onload = this.handleReaderLoaded.bind(this);
            reader.readAsBinaryString(file);
        }
    }

    handleReaderLoaded(e: any): any {
        this.base64textString = btoa(e.target.result);
    }


    getProduct() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getProductsById + '/' + localStorage.getItem('product_id')).subscribe((response: any) => {
                console.log(response);
                this.product = response;
                this.oldImage = this.product.image;
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

}
