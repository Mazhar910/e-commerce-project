import {Component, OnInit} from '@angular/core';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {NgxSpinnerService} from 'ngx-spinner';
import {InventoryApiService} from '../../InventoryApi.service';
import {InventoryEndPoints} from '../../InventoryEndPoints';
import {Router} from '@angular/router';
import {InventoryDialogService} from '../../_modal/InventoryDialog.service';
import {DialogModalComponent} from '../../_modal/dialog-modal/dialog-modal.component';
import {environment} from '../../../../environments/environment';

@Component({
    selector: 'app-product-create',
    templateUrl: './product-create.component.html',
    styleUrls: ['./product-create.component.css']
})
export class ProductCreateComponent implements OnInit {

    submitted = false;
    createData: FormGroup;
    updateData: FormGroup;
    fileName: any;
    base64textString: any;
    outlets: any;

    constructor(private modalService: NgbModal,
                private formBuilder: FormBuilder,
                private spinner: NgxSpinnerService,
                private apiService: InventoryApiService,
                private router: Router,
                private dialogService: InventoryDialogService,
                private endpoints: InventoryEndPoints) {
    }

    ngOnInit(): void {
        this.formInitialization();
        this.getAllOutlets();
    }

    formInitialization() {
        this.createData = new FormGroup({
            name: new FormControl('', [
                Validators.required,
            ]),

            purchasedPrice: new FormControl('', [
                Validators.required,
            ]),

            details: new FormControl('', [
                Validators.required,
            ]),

            outletStockQty: new FormControl('', [
                Validators.required,
            ]),

            stockType: new FormControl('In house', [
                Validators.required,
            ]),

            brandName: new FormControl('', [
                Validators.required,
            ]),

            sellingPrice: new FormControl('', [
                Validators.required,
            ]),

            vendorDetails: new FormControl('', [
                Validators.required,
            ]),


            alertQty: new FormControl('', [
                Validators.required,
            ]),

            numOfService: new FormControl('', [
                Validators.required,
            ]),

            code: new FormControl('', [
                Validators.required,
            ]),

            isActive: new FormControl(true),
            isDeleted: new FormControl(false),
            image: new FormControl(''),
            createdDate: new FormControl((new Date).getTime())
        });
    }

    create(product_image, outlet_id) {
        this.spinner.show();
        this.onUploadChange(product_image.files[0]);

        setTimeout(() => {
            this.createData.addControl('image', new FormControl(this.base64textString));
            this.createData.addControl('createdBy', new FormControl(1));
            this.createData.addControl('outletId', new FormControl(outlet_id));

            console.log(this.createData.value);

            this.apiService.post(this.createData.value, this.endpoints.createProduct).subscribe((response: any) => {
                    console.log(response);
                    this.spinner.hide();
                    if (response.status) {
                        this.dialogService.open(response.data.message, response.message, 'success', environment.info);
                    } else {
                        this.dialogService.open(response.data.message, response.message, 'danger', environment.error);
                    }
                    this.createData.reset();
                    this.formInitialization();
                },
                error => {
                    this.spinner.hide();
                    this.dialogService.open('Something went wrong!', environment.error_message, 'danger', environment.error);
                }
            );
        }, 500);

    }

    onUploadChange(file: any): any {
        if (file) {
            const reader = new FileReader();
            this.fileName = file.name;
            reader.onload = this.handleReaderLoaded.bind(this);
            reader.readAsBinaryString(file);
        }
    }

    handleReaderLoaded(e: any): any {
        this.base64textString = btoa(e.target.result);
    }

    getAllOutlets() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getOutlets).subscribe((response: any) => {
                console.log(response);
                this.outlets = response;
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }
}
