import {environment} from '../../environments/environment';
import {OnInit} from '@angular/core';

export class InventoryEndPoints {
    private baseUrl = environment.base_url;

    public readonly createProduct = this.baseUrl + 'api/product/create';
    public readonly updateProduct = this.baseUrl + 'api/product/update';
    public readonly getProducts = this.baseUrl + 'api/product/get/all';
    public readonly getProductsById = this.baseUrl + 'api/product/get-by-id';
    public readonly getProductsByOutletId = this.baseUrl + 'api/product/get-by/outlet';
    public readonly deleteProduct = this.baseUrl + 'api/product/delete';

    public readonly createTransaction = this.baseUrl + 'api/transaction/create';
    public readonly getTransaction = this.baseUrl + 'api/transaction/get/all';
    public readonly getTransactionById = this.baseUrl + 'api/transaction/get-by-id';
    public readonly getTransactionByOutletId = this.baseUrl + 'api/transaction/get-by/outlet';
    public readonly updateTransaction = this.baseUrl + 'api/transaction/update';
    public readonly deletetransaction = this.baseUrl + 'api/transaction/delete';


    public readonly getOutlets = this.baseUrl + 'api/outlets/get/all';
    public readonly stockReport = this.baseUrl + 'api/outlets/get/all/stock';
    public readonly stockReportByOutlet = this.baseUrl + 'api/outlets/get-by/outlet';
}
