import {Component, OnInit} from '@angular/core';
import {NgxSpinnerService} from 'ngx-spinner';
import {InventoryApiService} from '../../InventoryApi.service';
import {Router} from '@angular/router';
import {InventoryEndPoints} from '../../InventoryEndPoints';
import {HttpClient} from '@angular/common/http';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {InventoryDialogService} from '../../_modal/InventoryDialog.service';
import {environment} from '../../../../environments/environment';

@Component({
    selector: 'app-transaction-create',
    templateUrl: './transaction-create.component.html',
    styleUrls: ['./transaction-create.component.css']
})
export class TransactionCreateComponent implements OnInit {
    outletsFrom: any;
    outletsTo: any;
    outlets: any;

    productsList: any;
    products: any;

    singleDropdownSettings = {};
    closeDropdownSelection = false;

    createData: FormGroup;
    qOptionForm: FormGroup;

    transData = [];
    userId: any;

    constructor(private spinner: NgxSpinnerService,
                private apiService: InventoryApiService,
                private router: Router,
                private endpoints: InventoryEndPoints,
                private http: HttpClient,
                private fb: FormBuilder,
                private dialogService: InventoryDialogService) {
        this.createData = this.fb.group({
            qOptions: this.fb.array([]),
        });
    }


    ngOnInit(): void {
        this.getAllOutlets();
        this.getAllProducts();
        this.singleDropdownSettings = {
            singleSelection: true,
            allowSearchFilter: true,
            idField: 'id',
            textField: 'name',
            closeDropDownOnSelection: this.closeDropdownSelection
        };
        this.userId = 1;
    }

    create() {
        const items = this.createData.value.qOptions;
        for (let i = 0; i < items.length; i++) {
            console.log(items[i]);
            if (items[i].products == null || items[i].from == null || items[i].to == null) {
                this.dialogService.open('Please select all required fields', environment.warning_message, 'warning', environment.warning);
                return;
            }
            const data = {
                'pid': items[i].products[0].id,
                'from': items[i].from[0].id,
                'to': items[i].to[0].id,
                'entryType': 'Transfer',
                'adjustmentType': 'ADDED',
                'adjustmentAmount': items[i].inStock,
                'transactionDate': (new Date).getTime(),
                'createdBy': this.userId
            };
            this.transData.push(data);
        }

        console.log(this.transData);

        this.spinner.show();

        this.apiService.post(this.transData, this.endpoints.createTransaction).subscribe((response: any) => {
                console.log(response);
                this.dialogService.open(response.data.message, response.message, 'success', environment.info);
                this.qOptions.clear();
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    newOption(): FormGroup {
        return this.qOptionForm = this.fb.group({
            from: new FormControl(null, [Validators.required]),
            to: new FormControl(null, [Validators.required]),
            products: new FormControl(null, [Validators.required]),
            inStock: new FormControl('', [Validators.required]),
        });
    }

    addOption() {
        this.qOptions.push(this.newOption());
        this.getAllOutlets();
        console.log(this.outlets);
    }

    removeItem(i: number) {
        this.qOptions.removeAt(i);
    }

    get qOptions() {
        return this.createData.controls['qOptions'] as FormArray;
    }

    getAllOutlets() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getOutlets).subscribe((response: any) => {
                console.log(response);
                this.outlets = response;
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    getAllProducts() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getProducts).subscribe((response: any) => {
                console.log(response);
                this.productsList = response;
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    onItemSelect() {
        this.closeDropdownSelection = true;
    }
}
