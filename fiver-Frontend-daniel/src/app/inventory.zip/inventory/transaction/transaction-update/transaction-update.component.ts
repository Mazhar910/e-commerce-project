import {AfterViewInit, Component, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {NgxSpinnerService} from 'ngx-spinner';
import {InventoryApiService} from '../../InventoryApi.service';
import {Router} from '@angular/router';
import {InventoryEndPoints} from '../../InventoryEndPoints';
import {HttpClient} from '@angular/common/http';
import {InventoryDialogService} from '../../_modal/InventoryDialog.service';
import {environment} from '../../../../environments/environment';

@Component({
    selector: 'app-transaction-update',
    templateUrl: './transaction-update.component.html',
    styleUrls: ['./transaction-update.component.css']
})
export class TransactionUpdateComponent implements OnInit, AfterViewInit {

    outletsFrom: any;
    outletsTo: any;
    outlets: any;

    transaction: any;
    adjustmentAmount: any;

    productsList: any;
    products: any;

    singleDropdownSettings = {};
    closeDropdownSelection = false;

    createData: FormGroup;
    qOptionForm: FormGroup;

    userId: any;
    oldFrom = [];
    toFrom = [];
    oldProduct = [];

    constructor(private spinner: NgxSpinnerService,
                private apiService: InventoryApiService,
                private router: Router,
                private endpoints: InventoryEndPoints,
                private http: HttpClient,
                private fb: FormBuilder,
                private dialogService: InventoryDialogService) {
        this.createData = this.fb.group({
            from: new FormControl(null, [Validators.required]),
            to: new FormControl(null, [Validators.required]),
            products: new FormControl(null, [Validators.required]),
            inStock: new FormControl('', [Validators.required]),
        });
    }

    ngAfterViewInit(): void {

    }

    ngOnInit(): void {
        this.getAllOutlets();
        this.getAllProducts();
        this.getTransaction();

        setTimeout(() => {
            for (let i = 0; i < this.outlets.length; i++) {
                if (this.transaction.from.id === this.outlets[i].id) {
                    this.oldFrom = [
                        {id: this.outlets[i].id, name: this.outlets[i].name},
                    ];
                }

                if (this.transaction.to.id === this.outlets[i].id) {
                    this.toFrom = [
                        {id: this.outlets[i].id, name: this.outlets[i].name},
                    ];
                }
            }

            for (let i = 0; i < this.productsList.length; i++) {
                if (this.transaction.products.id === this.productsList[i].id) {
                    this.oldProduct = [
                        {id: this.productsList[i].id, name: this.productsList[i].name},
                    ];
                }
            }

            console.log(this.oldFrom);
        }, 500);

        this.singleDropdownSettings = {
            singleSelection: true,
            allowSearchFilter: true,
            idField: 'id',
            textField: 'name',
            closeDropDownOnSelection: this.closeDropdownSelection
        };
        this.userId = 1;
    }

    update() {
        const items = this.createData.value;
        console.log(items);

        this.spinner.show();
        const data = {
            'pid': items.products[0].id,
            'from': items.from[0].id,
            'to': items.to[0].id,
            'entryType': 'Transfer',
            'adjustmentType': 'ADDED',
            'adjustmentAmount': items.inStock,
            'transactionDate': (new Date).getTime(),
            'createdBy': this.userId
        };
        console.log(data);

        this.apiService.put(data, this.endpoints.updateTransaction, localStorage.getItem('trans_id')).subscribe((response: any) => {
                console.log(response);
                this.dialogService.open(response.data.message, response.message, 'success', environment.info);
                this.qOptions.clear();
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    newOption(): FormGroup {
        return this.qOptionForm = this.fb.group({
            from: new FormControl(null, [Validators.required]),
            to: new FormControl(null, [Validators.required]),
            products: new FormControl(null, [Validators.required]),
            inStock: new FormControl('', [Validators.required]),
        });
    }

    addOption() {
        if (this.qOptions.length < 5) {
            this.qOptions.push(this.newOption());
        }
        this.getAllOutlets();
        console.log(this.outlets);
    }

    removeItem(i: number) {
        this.qOptions.removeAt(i);
    }

    get qOptions() {
        return this.createData.controls['qOptions'] as FormArray;
    }

    getAllOutlets() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getOutlets).subscribe((response: any) => {
                console.log(response);
                this.outlets = response;
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    getAllProducts() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getProducts).subscribe((response: any) => {
                console.log(response);
                this.productsList = response;
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    getTransaction() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getTransactionById + '/' + localStorage.getItem('trans_id')).subscribe((response: any) => {
                console.log(response);
                this.transaction = response;
                this.adjustmentAmount = response.adjustmentAmount;
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }


}
