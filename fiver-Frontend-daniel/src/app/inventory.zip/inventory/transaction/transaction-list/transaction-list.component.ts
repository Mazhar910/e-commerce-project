import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {DataTableDirective} from 'angular-datatables';
import {Subject} from 'rxjs';
import {NgxSpinnerService} from 'ngx-spinner';
import {InventoryApiService} from '../../InventoryApi.service';
import {Router} from '@angular/router';
import {InventoryEndPoints} from '../../InventoryEndPoints';
import {HttpClient} from '@angular/common/http';

class DataTablesResponse {
    data: any[];
    draw: number;
    recordsFiltered: number;
    recordsTotal: number;
}

@Component({
    selector: 'app-transaction-list',
    templateUrl: './transaction-list.component.html',
    styleUrls: ['./transaction-list.component.css']
})
export class TransactionListComponent implements OnInit, AfterViewInit {

    @ViewChild(DataTableDirective, {static: false})
    dtElement: DataTableDirective;
    dtOptions: DataTables.Settings = {};
    dtTrigger: Subject<any> = new Subject();
    transaction: any;
    outlets: any;

    constructor(private spinner: NgxSpinnerService,
                private apiService: InventoryApiService,
                private router: Router,
                private endpoints: InventoryEndPoints,
                private http: HttpClient) {
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnInit(): void {
        this.getAllProduct();
        this.loadDatatables(0);
        this.getAllOutlets();
    }

    loadDatatables(outletId) {
        const that = this;
        this.dtOptions = {
            pagingType: 'simple_numbers',
            pageLength: 5,
            serverSide: true,
            processing: true,
            ajax: (dataTablesParameters: any, callback) => {
                that.http.post<DataTablesResponse>(this.endpoints.getTransactionByOutletId + '/' + outletId,
                    dataTablesParameters, {}
                ).subscribe(resp => {
                    that.transaction = resp.data;
                    callback({
                        recordsTotal: resp.recordsTotal,
                        recordsFiltered: resp.recordsFiltered,
                        data: []
                    });
                });
            },
            searching: true,
            columns: [
                {data: 'products.name', searchable: true},
                {data: 'products.stockType', searchable: false},
                {data: 'transactionDate', searchable: false},
                {data: 'adjustmentType', searchable: false},
                {data: 'adjustmentAmount', searchable: false},
                {data: 'stockInHand', searchable: false},
                {data: 'from.name', searchable: false},
                {data: 'to.name', searchable: false},
            ]
        };
    }

    getAllProduct() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getProducts).subscribe((response: any) => {
                console.log(response);
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    gotoUpdate(id) {
        localStorage.removeItem('trans_id');
        this.router.navigate(['transaction/update']);
        localStorage.setItem('trans_id', id);
    }

    deleteData(id) {
        this.spinner.show();
        this.apiService.delete(id, this.endpoints.deletetransaction).subscribe((response: any) => {
                this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
                    dtInstance.destroy();
                    this.loadDatatables(0);
                    setTimeout(() => {
                        this.dtTrigger.next();
                        this.spinner.hide();
                    }, 1500);
                });
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    getAllOutlets() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getOutlets).subscribe((response: any) => {
                console.log(response);
                this.outlets = response;
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    filterByOutletId(outletId) {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.loadDatatables(outletId);
            setTimeout(() => {
                this.dtTrigger.next();
                this.spinner.hide();
            }, 500);
        });
    }
}
