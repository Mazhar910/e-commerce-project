import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {DataTableDirective} from 'angular-datatables';
import {Subject} from 'rxjs';
import {NgxSpinnerService} from 'ngx-spinner';
import {InventoryApiService} from '../../InventoryApi.service';
import {Router} from '@angular/router';
import {InventoryEndPoints} from '../../InventoryEndPoints';
import {HttpClient} from '@angular/common/http';

class DataTablesResponse {
    data: any[];
    draw: number;
    recordsFiltered: number;
    recordsTotal: number;
}

@Component({
    selector: 'app-stock-report',
    templateUrl: './stock-report.component.html',
    styleUrls: ['./stock-report.component.css']
})
export class StockReportComponent implements OnInit, AfterViewInit {


    @ViewChild(DataTableDirective, {static: false})
    dtElement: DataTableDirective;
    dtOptions: DataTables.Settings = {};
    dtTrigger: Subject<any> = new Subject();
    stockReports: any;
    outlets: any;

    constructor(private spinner: NgxSpinnerService,
                private apiService: InventoryApiService,
                private router: Router,
                private endpoints: InventoryEndPoints,
                private http: HttpClient) {
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnInit(): void {
        this.getAllProduct();
        this.getAllOutlets();
        this.loadDatatables(0);
    }

    loadDatatables(outletId) {
        const that = this;
        this.dtOptions = {
            pagingType: 'simple_numbers',
            pageLength: 5,
            serverSide: true,
            processing: true,
            ajax: (dataTablesParameters: any, callback) => {
                that.http.post<DataTablesResponse>(this.endpoints.stockReportByOutlet + '/' + outletId,
                    dataTablesParameters, {}
                ).subscribe(resp => {
                    that.stockReports = resp.data;
                    callback({
                        recordsTotal: resp.recordsTotal,
                        recordsFiltered: resp.recordsFiltered,
                        data: []
                    });
                });
            },
            searching: true,
            columns: [
                {data: 'products.name', searchable: true},
                {data: 'products.stockType', searchable: false},
                {data: 'outlets.name', searchable: false},
                {data: 'stockQty', searchable: false},
                {data: 'updatedDate', searchable: false}
            ]
        };
    }

    getAllProduct() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getProducts).subscribe((response: any) => {
                console.log(response);
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    getAllOutlets() {
        this.spinner.show();
        this.apiService.get('', this.endpoints.getOutlets).subscribe((response: any) => {
                console.log(response);
                this.outlets = response;
            },
            error => {
                this.spinner.hide();
            }
        );
        this.spinner.hide();
    }

    gotoUpdate(id) {
        localStorage.removeItem('trans_id');
        this.router.navigate(['transaction/update']);
        localStorage.setItem('trans_id', id);
    }

    filterByOutletId(outletId) {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.loadDatatables(outletId);
            setTimeout(() => {
                this.dtTrigger.next();
                this.spinner.hide();
            }, 500);
        });
    }
}
